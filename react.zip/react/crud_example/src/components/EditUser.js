import React, { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import UserForm from "./UserForm";
import * as Yup from "yup";

function EditUser() {
  const [user, setUser] = useState({});
  const { id } = useParams();
  const Navigate = useNavigate();

  const validationSchema = Yup.object({
    name: Yup.string().required("Name is required"),
  });
  useEffect(() => {
    fetch(`http://localhost:8000/users/${id}`)
      .then((response) => response.json())
      .then((data) => setUser(data));
  }, [id]);

  const handleSubmit = (values) => {
    fetch(`http://localhost:8000/users/${id}`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(values),
    })
      .then(() => Navigate("/users"))
      .catch((error) => console.error(error));
  };

  return <UserForm initialValues={user} onSubmit={handleSubmit} />;
}

export default EditUser;
