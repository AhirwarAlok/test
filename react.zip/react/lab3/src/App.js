import logo from './logo.svg';
import './App.css';
import FormikAndYup from './component/FormikAndYup';

function App() {
  return (
    <div className="App">
      <FormikAndYup> </FormikAndYup>
    </div>
  );
}

export default App;
