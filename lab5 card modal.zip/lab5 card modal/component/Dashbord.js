import React from "react";
import { Link } from "react-router-dom";

function Dashbord() {
  return (
    <div className="container">
      <h2 className="mt-4">Dashboard</h2>
      <div className="card">
        <div className="card-body">
          <p>This is dashboard</p>
        </div>
      </div>
    </div>
  );
}

export default Dashbord;
