import React from "react";

function Admin() {
  return (
    <div className="container">
      <h2 className="mt-4">Admin</h2>
      <div className="card">
        <div className="card-body">
          <p>this is admin page</p>
        </div>
      </div>
    </div>
  );
}

export default Admin;
