import React from "react";

function Home() {
  return (
    <div
      className="d-flex justify-content-center align-items-center"
      style={{
        minHeight: "94vh",
        textAlign: "center"
      }}
    >
      <div>
        <h2>Hi!, My name is Ahirwar Alok</h2>
        <div>
          <h3>I'm a React Developer</h3>
        </div>
      </div>
    </div>
  );
}

export default Home;
