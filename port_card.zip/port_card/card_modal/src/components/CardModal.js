import React, { useState, useEffect } from "react";
import axios from "axios";
import "./modal.css";
import { FaEdit, FaIcons, FaTrash } from "react-icons/fa";

function CardModal() {
  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [newTask, setNewTask] = useState({
    id: "",
    title: "",
    description: "",
  });
  const [tasks, setTasks] = useState([]);

  const handleOpenAddModal = () => {
    setShowAddModal(true);
  };

  const handleCloseAddModal = () => {
    setShowAddModal(false);
  };

  const handleOpenEditModal = (task) => {
    setNewTask(task);
    setShowEditModal(true);
  };

  const handleCloseEditModal = () => {
    setNewTask({ id: "", title: "", description: "" });
    setShowEditModal(false);
  };

  const handleSubmitAdd = (e) => {
    e.preventDefault();
    axios
      .post("http://localhost:8000/Tasks", newTask)
      .then((response) => {
        const updatedTasks = [...tasks, response.data];
        setTasks(updatedTasks);
        setNewTask({ id: "", title: "", description: "" });
        handleCloseAddModal();
      })
      .catch((error) => {
        console.error("Error creating new task:", error);
      });
  };

  const handleSubmitEdit = (e) => {
    e.preventDefault();
    axios
      .put(`http://localhost:8000/Tasks/${newTask.id}`, newTask)
      .then(() => {
        const updatedTasks = tasks.map((task) =>
          task.id === newTask.id ? newTask : task
        );
        setTasks(updatedTasks);
        setNewTask({ id: "", title: "", description: "" });
        handleCloseEditModal();
      })
      .catch((error) => {
        console.error( error);
      });
  };

  const handleDeleteTask = (taskId) => {
    axios
      .delete(`http://localhost:8000/Tasks/${taskId}`)
      .then(() => {
        const updatedTasks = tasks.filter((task) => task.id !== taskId);
        setTasks(updatedTasks);
      })
      .catch((error) => {
        console.error("Error deleting task:", error);
      });
  };

  useEffect(() => {
    axios
      .get("http://localhost:8000/Tasks")
      .then((response) => setTasks(response.data))
      .catch((error) => console.error(error));
  }, []);

  return (
    <div>
      <div className="jumbotron jumbotron-fluid">
        <div
          className="container bg-info mw-100"
          style={{ minHeight: "200px" }}
        >
          <h1 className="display-4">Tasks</h1>
          <p className="lead">Do you want to add a new task?</p>
          <button className="btn btn-primary" onClick={handleOpenAddModal}>
            Add Task
          </button>
        </div>
      </div>
      <div className="container">
        <div className="row mt-5">
          {tasks.map((task) => (
            <div className="col-2 mt-4" key={task.id}>
              <div className="card">
                <div className="card-body">
                  <h5 className="card-title">{task.title}</h5>
                  <p className="card-text">{task.description}</p>
                  <div className="d-flex justify-content-center">
                    <div className="" style={{marginRight: '1em'}} onClick={() => handleOpenEditModal(task)}>
                      <FaEdit />
                    </div>
                    <div onClick={() => handleDeleteTask(task.id)}>
                      <FaTrash />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {showAddModal && (
        <div className="modal">
          <div className="modal-content">
            <div>
              <h2>Task Form</h2>
              <form onSubmit={handleSubmitAdd}>
                <div className="form-group" style={{textAlign:"left"}}>
                  <label >Title:</label>
                  <input
                    type="text"
                    id="title"
                    name="title"
                    className="form-control"
                    value={newTask.title}
                    onChange={(e) =>
                      setNewTask({ ...newTask, title: e.target.value })
                    }
                    required
                  />
                </div>
                <div className="form-group" style={{textAlign:"left"}}>
                  <label >Description:</label>
                  <textarea
                    id="description"
                    name="description"
                    className="form-control"
                    value={newTask.description}
                    onChange={(e) =>
                      setNewTask({ ...newTask, description: e.target.value })
                    }
                    required
                  ></textarea>
                </div>
                <br/>
                <button type="submit" className="btn btn-primary" style={{marginRight: '1em'}}>
                  Create Task
                </button>
                <button
                  type="button"
                  className="btn btn-primary"
                  onClick={handleCloseAddModal}
                >
                  Cancel
                </button>
              </form>
            </div>
          </div>
        </div>
      )}

      {showEditModal && (
        <div className="modal">
          <div className="modal-content">
            <div>
              <h2>Edit Task</h2>
              <form onSubmit={handleSubmitEdit}>
                <div className="form-group" style={{textAlign:"left"}}>
                  <label >Title:</label>
                  <input
                    type="text"
                    id="title"
                    name="title"
                    className="form-control"
                    value={newTask.title}
                    onChange={(e) =>
                      setNewTask({ ...newTask, title: e.target.value })
                    }
                    required
                  />
                </div>
                <div className="form-group" style={{textAlign:"left"}}>
                  <label >Description:</label>
                  <textarea
                    id="description"
                    name="description"
                    className="form-control"
                    value={newTask.description}
                    onChange={(e) =>
                      setNewTask({ ...newTask, description: e.target.value })
                    }
                    required
                  ></textarea>
                </div>
                <br/>
                <button type="submit" className="btn btn-primary" style={{marginRight: '1em'}}>
                  Update Task
                </button>
                <button
                  type="button"
                  className="btn btn-primary"
                  onClick={handleCloseEditModal}
                >
                  Cancel
                </button>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default CardModal;
