import React from "react";
import { Link } from "react-router-dom";

function Dashbord() {
  return (
    <div className="container">
      <h2>Dashboard</h2>
      <div>Welcome to the dashboard!</div>
    </div>
  );
}

export default Dashbord;
