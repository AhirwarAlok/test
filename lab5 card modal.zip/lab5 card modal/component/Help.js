import React from 'react'

function Help() {
  return (
    <div className="container">
      <h2 className="mt-4">Help</h2>
      <div className="card">
        <div className="card-body">
          <p>This is the Help page.</p>
          <p>If you need assistance, come here.</p>
        </div>
      </div>
    </div>
  )
}

export default Help