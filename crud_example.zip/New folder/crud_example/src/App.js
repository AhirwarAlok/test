import "./App.css";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import UserList from "./components/UserList";
import EditUser from "./components/EditUser";
import CreateUser from "./components/CreateUser";

function App() {
  return (
    <Router>
      <nav className="navbar navbar-expand navbar-dark bg-dark">
        <div className="navbar-brand">CRUD with Formik and Yup </div>
        <ul className="navbar-nav">
          <li className="nav-item">
            <Link to="/users" className="nav-link">
              User List
            </Link>
          </li>
          <li className="nav-item">
            <Link to="/users/create" className="nav-link">
              Create User
            </Link>
          </li>
        </ul>
      </nav>
      <div className="container mt-4">
        <Routes>
          <Route path="/users/create" element={<CreateUser />} />
          <Route path="/users/:id" element={<EditUser />} />
          <Route path="/users" element={<UserList />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
