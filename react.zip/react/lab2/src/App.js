import logo from './logo.svg';
import './App.css';
import Parent from './components/Parent'
import Userdetails from './components/Userdetails';

function App() {
  return (
    <div className="App">
      <Userdetails/>
    </div>
  );
}

export default App;
