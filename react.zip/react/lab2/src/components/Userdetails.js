import React, { useState } from "react";
import UseRegistraion from "./UserRegistration";

function Userdetails() {
  const [userDetails, setUserDetails] = useState({
    username: "",
    email: "",
    password: "",
    confirmPassword: "",
  });
  const passdata = (data) => {
    setUserDetails(data);
  };
  return (
    <div>
      <UseRegistraion passdata={passdata} />
      <h1>userDetails component:</h1>
      <div>
        <b>Username:</b>
        {userDetails.username}
      </div>
      <div><b>email:</b>: {userDetails.email}</div>
      <div><b>password:</b>: {userDetails.password}</div>
    </div>
  );
}

export default Userdetails;
