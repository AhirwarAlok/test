import React from "react";

function Projects() {
  const projects = [
    {
      title: "Java Project",
      description: "This is description for java project made using maven tool",
    },
    {
      title: "Sample Project 2",
      description:
        "This is description text filler for the card of Sample porject 2",
    },
    {
      title: "Sample Project 3",
      description:
        "This is description text filler for the card of Sample porject 3",
    },
    {
      title: "Sample Project 4",
      description:
        "This is description text filler for the card of Sample porject 4",
    },
    {
      title: "Sample Project 5",
      description:
        "This is description text filler for the card of Sample porject 5",
    },
  ];

  return (
    <div className="container mt-5" style={{
      minHeight: "94vh",
    }}>
      <h2 className="mb-4">Projects</h2>
      <div className="row">
        {projects.map((project, index) => (
          <div className="col-md-4" key={index}>
            <div className="card mb-4">
              <div className="card-body">
                <h5 className="card-title">{project.title}</h5>
                <p className="card-text">{project.description} </p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Projects;
