import logo from './logo.svg';
import './App.css';
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Home from './components/Home'
import Projects from './components/Projects'
import Experience from './components/Experience'
import Navbar from './components/navbar';

function App() {
  return (
    <div className="App" style={{
      background: "linear-gradient(to bottom, #f2f2f2, #d9d9d9)",
    }}>
      <Router>
        <Navbar/>
        <Routes>
          <Route path='/' element={<Home/>}/>
          <Route path='/projects' element={<Projects />}/>
          <Route path='/Experience' element={<Experience />}/>
        </Routes>
      </Router>
    </div>
  );
}

export default App;
