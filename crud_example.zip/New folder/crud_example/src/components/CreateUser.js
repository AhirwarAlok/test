import React from "react";
import { useNavigate } from 'react-router-dom';
import UserForm from "./UserForm";

function CreateUser() {
    const Navigate = useNavigate();

  const handleSubmit = (values) => {
    fetch("http://localhost:8000/users", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(values),
    })
      .then(() => Navigate("/users"))
      .catch((error) => console.error(error));
  };
  return <UserForm initialValues={{ name: "" }} onSubmit={handleSubmit} />;
}

export default CreateUser;
