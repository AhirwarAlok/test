import React, { useState, useEffect } from "react";
import axios from "axios";
import { FaEdit, FaTrash } from "react-icons/fa";
import Modal from "@mui/material/Modal";
import { Button, TextField } from "@mui/material";

function CardModal() {
  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [newTask, setNewTask] = useState({
    id: "",
    title: "",
    description: "",
  });
  const [tasks, setTasks] = useState([]);

  const handleOpenAddModal = () => {
    setShowAddModal(true);
  };

  const handleCloseAddModal = () => {
    setNewTask({ id: "", title: "", description: "" });
    setShowAddModal(false);
  };

  const handleOpenEditModal = (task) => {
    setNewTask(task);
    setShowEditModal(true);
  };

  const handleCloseEditModal = () => {
    setNewTask({ id: "", title: "", description: "" });
    setShowEditModal(false);
  };

  const handleSubmitAdd = (e) => {
    e.preventDefault();
    axios
      .post("http://localhost:8000/Tasks", newTask)
      .then((response) => {
        const updatedTasks = [...tasks, response.data];
        setTasks(updatedTasks);
        setNewTask({ id: "", title: "", description: "" });
        handleCloseAddModal();
      })
      .catch((error) => {
        console.error("Error creating new task:", error);
      });
  };

  const handleSubmitEdit = (e) => {
    e.preventDefault();
    axios
      .put(`http://localhost:8000/Tasks/${newTask.id}`, newTask)
      .then(() => {
        const updatedTasks = tasks.map((task) =>
          task.id === newTask.id ? newTask : task
        );
        setTasks(updatedTasks);
        setNewTask({ id: "", title: "", description: "" });
        handleCloseEditModal();
      })
      .catch((error) => {
        console.error(error);
      });
  };

  const handleDeleteTask = (taskId) => {
    axios
      .delete(`http://localhost:8000/Tasks/${taskId}`)
      .then(() => {
        const updatedTasks = tasks.filter((task) => task.id !== taskId);
        setTasks(updatedTasks);
      })
      .catch((error) => {
        console.error("Error deleting task:", error);
      });
  };

  useEffect(() => {
    axios
      .get("http://localhost:8000/Tasks")
      .then((response) => setTasks(response.data))
      .catch((error) => console.error(error));
  }, []);

  return (
    <div>
      <div className="jumbotron jumbotron-fluid">
        <div
          className="container bg-info mw-100"
          style={{ minHeight: "200px" }}
        >
          <h1 className="display-4">Tasks</h1>
          <p className="lead">Do you want to add a new task?</p>
          <button className="btn btn-primary" onClick={handleOpenAddModal}>
            Add Task
          </button>
        </div>
      </div>
      <div className="container">
        <div className="row mt-5">
          {tasks.map((task) => (
            <div className="col-sm-2 mt-4" key={task.id}>
              <div className="card">
                <div className="card-body">
                  <h5 className="card-title">{task.title}</h5>
                  <p className="card-text">{task.description}</p>
                  <div className="d-flex justify-content-center">
                    <div
                      className=""
                      style={{ marginRight: "1em" }}
                      onClick={() => handleOpenEditModal(task)}
                    >
                      <FaEdit />
                    </div>
                    <div onClick={() => handleDeleteTask(task.id)}>
                      <FaTrash />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
      <Modal open={showAddModal} onClose={handleCloseAddModal}>
        <div
          style={{
            position: "absolute",
            top: "50%",
            left: "50%",
            transform: "translate(-50%, -50%)",
            backgroundColor: "white",
            padding: "2rem",
            outline: "none",
            borderRadius: "5px",
            
          }}
        >
          <h2>Add Task</h2>
          <form onSubmit={handleSubmitAdd}>
            <div style={{ marginBottom: "1rem" }}>
              <TextField
                label="Task Title"
                type="text"
                id="title"
                name="title"
                value={newTask.title}
                onChange={(e) =>
                  setNewTask({ ...newTask, title: e.target.value })
                }
                required
              />
            </div>
            <div style={{ marginBottom: "1rem" }}>
              <TextField
                label="Description"
                type="text"
                id="description"
                name="description"
                value={newTask.description}
                onChange={(e) =>
                  setNewTask({ ...newTask, description: e.target.value })
                }
                required
              />
            </div>
            <div >
              <Button
                type="submit"
                variant="contained"
                color="primary"
                style={{ marginRight: "1em" }}
              >
                Create Task
              </Button>
              <Button
                variant="contained"
                color="primary"
                onClick={handleCloseAddModal}
              >
                Cancel
              </Button>
            </div>
          </form>
        </div>
      </Modal>

      <Modal open={showEditModal} onClose={handleCloseEditModal}>
        <div
          style={{
            position: "absolute",
            top: "50%",
            left: "50%",
            transform: "translate(-50%, -50%)",
            backgroundColor: "white",
            padding: "2rem",
            outline: "none",
            borderRadius: "5px",
            minWidth: "300px",
          }}
        >
          <h2>Edit Task</h2>
          <form onSubmit={handleSubmitEdit}>
            <div style={{ marginBottom: "1rem" }}>
              <TextField
                label="Task Title"
                type="text"
                id="title"
                name="title"
                value={newTask.title}
                onChange={(e) =>
                  setNewTask({ ...newTask, title: e.target.value })
                }
                required
              />
            </div>
            <div style={{ marginBottom: "1rem" }}>
              <TextField
                label="Description"
                id="description"
                name="description"
                value={newTask.description}
                onChange={(e) =>
                  setNewTask({ ...newTask, description: e.target.value })
                }
                required
              />
            </div>
            <div style={{ textAlign: "right" }}>
              <Button
                type="submit"
                variant="contained"
                color="primary"
                style={{ marginRight: "1em" }}
              >
                Update Task
              </Button>
              <Button
                variant="contained"
                color="primary"
                onClick={handleCloseEditModal}
              >
                Cancel
              </Button>
            </div>
          </form>
        </div>
      </Modal>
    </div>
  );
}

export default CardModal;
