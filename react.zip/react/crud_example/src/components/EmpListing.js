import React from 'react'

function EmpListing() {
  return (
    <div className='container'>
        <div className='card-title'>
            <h2>Empolyee list</h2>
        </div>
        <div className='card-body'>
            <table className='table table-bordered'>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                </tr>
            </table>
        </div>
    </div>
  )
}

export default EmpListing