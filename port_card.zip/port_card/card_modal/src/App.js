import "./App.css";
import CardModal from "./components/CardModal";

function App() {
  return (
    <div className="App">
    <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
      <div className="container">
        <div className="navbar-brand">
          Card with Modal
        </div>
      </div>
    </nav>
    <CardModal/>
  </div>
  );
}

export default App;
