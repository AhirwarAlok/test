import logo from './logo.svg';
import './App.css';
import UserRegistration from './components/UserRegistration';

function App() {
  return (
    <div>
      <UserRegistration/>
    </div>
  );
}

export default App;
