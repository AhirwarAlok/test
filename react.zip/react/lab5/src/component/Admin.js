import React from 'react'

function Admin() {
  return (
    <div>This is Admin page</div>
  )
}

export default Admin