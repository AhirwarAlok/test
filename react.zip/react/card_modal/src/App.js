import "./App.css";

function App() {
  return (
    <div className="App">
      <h1>card modal demo</h1>
    </div>
  );
}

export default App;
