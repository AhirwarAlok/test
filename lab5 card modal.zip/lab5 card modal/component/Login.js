import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

const Login = ({ setLoggedInUser }) => {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState("");

  const Navigate = useNavigate();

  const handleLogin = () => {
    const user = { role: role };
    setLoggedInUser(user);
    Navigate("/dashboard");
  };

  return (
    <div className="container mt-5 w-75">
      <h2>Login Page</h2>
      <div className="form-group">
        <label>Username:</label>
        <input
          type="text"
          className="form-control"
          id="username"
          placeholder="Username"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
        />
      </div>
      <br />
      <div className="form-group">
        <label>Password:</label>
        <input
          type="password"
          className="form-control"
          id="password"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
      </div>
      <br />
      <div className="form-group">
        <label>User Type:</label>
        <div className="form-check">
          <input
            type="radio"
            className="form-check-input"
            id="user"
            name="role"
            value="User"
            checked={role === "User"}
            onChange={(e) => setRole(e.target.value)}
          />
          <label className="form-check-label" htmlFor="user">
            User
          </label>
        </div>
        <div className="form-check">
          <input
            type="radio"
            className="form-check-input"
            id="admin"
            name="role"
            value="Admin"
            checked={role === "Admin"}
            onChange={(e) => setRole(e.target.value)}
          />
          <label className="form-check-label" htmlFor="admin">
            Admin
          </label>
        </div>
      </div>
      <br />
      <button className="btn btn-primary" onClick={handleLogin}>
        Login
      </button>
    </div>
  );
};

export default Login;
