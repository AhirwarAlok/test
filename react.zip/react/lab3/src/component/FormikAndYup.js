import React from "react";
import { useState, useEffect } from "react";
import PasswordChecklist from "react-password-checklist";
import { ErrorMessage, Field, Form, Formik } from "formik";
import * as Yup from "yup";

function FormikAndYup() {
  let initialvalues = {
    username: "",
    email: "",
    password: "",
  };

  let submit = (e) => {
    console.log(e);
  };

  let schema = Yup.object({
    username: Yup.string().required("required"),
    email: Yup.string().email('invalid email').required('email required'),
    password: Yup.string().required('password is reuired').min(4,'password should be more than 4 characters').matches(/[ -\/:-@\[-\`{-~]/,'Must include special charcter')
  });
  return (
    <Formik
      initialValues={initialvalues}
      validationSchema={schema}
      onSubmit={submit}
    >
      <div className="container">
        <Form>
          <h1>Formik and yup demo</h1>
          <div className="ui divider"></div>
          <div className="ui form">
            <div className="field">
              <label>Username</label>
              <Field type="text" name="username"></Field>
              <p>
                <ErrorMessage name="username"/>
              </p>
            </div>
            <div className="field">
              <label>Email</label>
              <Field type="text" name="email"></Field>
              <p>
                <ErrorMessage name="email"/>
              </p>
            </div>
            <div className="field">
              <label>Password</label>
              <Field type="password" name="password"></Field>
              <p>
                <ErrorMessage name="password"/>
              </p>
            </div>
            <button type="submit" className="fluid ui button blue">
              Submit
            </button>
          </div>
        </Form>
      </div>
    </Formik>
  );
}

export default FormikAndYup;

/* <form>
        <h1>Registration Form</h1>
        <div className="ui divider"></div>
        <div className="ui form">
          <div className="field">
            <label>Username</label>
            <input type="text" name="username" placeholder="Username" />
          </div>

          <div className="field">
            <label>Email</label>
            <input type="text" name="email" placeholder="Email" />
          </div>

          <div className="field">
            <label>Password</label>
            <input type="password" name="password" placeholder="Password" />
          </div>    
          <button className="fluid ui button blue">Submit</button>
        </div>
      </form> */
